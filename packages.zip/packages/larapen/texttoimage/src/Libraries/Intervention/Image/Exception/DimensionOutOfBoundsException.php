<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class DimensionOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
