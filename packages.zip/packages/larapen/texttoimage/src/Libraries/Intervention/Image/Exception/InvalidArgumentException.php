<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class InvalidArgumentException extends \RuntimeException
{
    # nothing to override
}
