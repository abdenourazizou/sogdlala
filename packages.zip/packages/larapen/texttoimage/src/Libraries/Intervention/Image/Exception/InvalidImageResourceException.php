<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class InvalidImageResourceException extends \RuntimeException
{
    # nothing to override
}
