<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ContrastOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
