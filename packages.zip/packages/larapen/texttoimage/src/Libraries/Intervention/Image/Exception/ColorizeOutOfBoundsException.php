<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ColorizeOutOfBoundsException extends \OutOfBoundsException
{
    # nothing to override
}
