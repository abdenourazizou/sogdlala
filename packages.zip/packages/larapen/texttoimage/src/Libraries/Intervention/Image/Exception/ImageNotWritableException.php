<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class ImageNotWritableException extends \RuntimeException
{
    # nothing to override
}
