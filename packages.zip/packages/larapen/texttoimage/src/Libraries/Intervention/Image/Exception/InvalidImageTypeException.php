<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class InvalidImageTypeException extends \RuntimeException
{
    # nothing to override
}
