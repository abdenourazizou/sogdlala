<?php

namespace Larapen\TextToImage\Libraries\Intervention\Image\Exception;

class InvalidImageDataStringException extends \RuntimeException
{
    # nothing to override
}
