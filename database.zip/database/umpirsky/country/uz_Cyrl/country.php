<?php return array(
    'UZ' => 'Ўзбекистон',
);
