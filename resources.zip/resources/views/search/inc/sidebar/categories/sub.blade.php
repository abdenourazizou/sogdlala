{{-- Category --}}
<div class="container mb-2">
	<div id="sub-catsList" style="overflow: hidden; border-top: solid 1px #f5f5f5;">
		<div class="search-category d-flex">
				@if (isset($cats) && $cats->count() > 0)
				{{-- @dd($cat) --}}
					@foreach ($cats as $iCat)
						<div class="f-category col-lg-2 col-sm-3">
							@if (isset($cat) && !empty($cat) && ($iCat->id == $cat->parent_id || $iCat->id == $cat->id))
								<strong>
									<a href="{{ \App\Helpers\UrlGen::category($iCat, null, $city ?? null) }}" class="active" title="{{ $iCat->name }}">
										<div class="circle">
											<div class="img-wrap">
												<img src="{{ imgUrl($iCat->picture, 'cat') }}" class="category-img lazyload img-fluid" alt="{{ $iCat->name }}">
											</div>
										</div>
										<h6 class="title">{{ $iCat->name }}</h6>
										@if (config('settings.listing.count_categories_posts'))
											<span class="count">&nbsp;{{ $countPostsByCat->get($iCat->id)->total ?? 0 }}</span>
										@endif
									</a>
								</strong>
							@else
								<a href="{{ \App\Helpers\UrlGen::category($iCat, null, $city ?? null) }}" title="{{ $iCat->name }}">
									<div class="circle">
										<div class="img-wrap">
											<img src="{{ imgUrl($iCat->picture, 'cat') }}" class="category-img lazyload img-fluid" alt="{{ $iCat->name }}">
										</div>
									</div>
	
									<h6 class="title">{{ $iCat->name }}</h6>
									@if (config('settings.listing.count_categories_posts'))
										<span class="count">&nbsp;{{ $countPostsByCat->get($iCat->id)->total ?? 0 }}</span>
									@endif
								</a>
							@endif
						</div>
					@endforeach
				@endif
		</div>
	</div>
</div>
