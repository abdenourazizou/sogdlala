<div class="container">
	<nav aria-label="breadcrumb" role="navigation" class="search-breadcrumb">
		<ol class="breadcrumb">
			{{-- <li class="breadcrumb-item"><a href="{{ url('/') }}"><i class="icon-home fa"></i></a></li>
			<li class="breadcrumb-item">
				<a href="{{ \App\Helpers\UrlGen::search() }}">
					{{ config('country.name') }}
				</a>
			</li> --}}
			@if (isset($bcTab) and is_array($bcTab) and count($bcTab) > 0)
				@foreach($bcTab as $key => $value)
					{{-- @dd($bcTab); --}}
					@if ($value->has('position') and $value->get('position') >= count($bcTab))
						<li class="breadcrumb-item active">
							<a role="button" class="breadcrumb-item-link">
								<div class="circle">
									<div class="img-wrap">
										<img src="{{ imgUrl($value->get("picture"), 'cat') }}" class="lazyload img-fluid w-100 h-100">
									</div>
								</div>
							</a>
							<span>
								{!! $value->get('name') !!}
							</span>
							@if (isset($city) or isset($admin))
								&nbsp;
								<a href="#browseAdminCities" data-bs-toggle="modal" class="breadcrumb-item-link"> <span class="caret"></span></a>
							@endif
						</li>
					@else
						<li class="breadcrumb-item">
							<a href="{{ $value->get('url') }}" class="breadcrumb-item-link">
								<div class="circle">
									<div class="img-wrap">
										<img src="{{ imgUrl($value->get("picture"), 'cat') }}" class="catagory-img lazyload img-fluid">
									</div>
								</div>
								<span>
									{!! $value->get('name') !!}
								</span>
							</a>
						</li>
					@endif
				@endforeach
			@endif
		</ol>
	</nav>
</div>
