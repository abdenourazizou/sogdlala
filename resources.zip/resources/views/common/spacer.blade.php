@if (!(isset($paddingTopExists) && $paddingTopExists))
	<div class="p-0 mt-lg-4 mt-md-3 mt-3"></div>
@endif