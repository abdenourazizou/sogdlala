<?php 

return [
    'password' => 'Le password devono contenere almeno otto caratteri e corrispondere alla conferma.',
    'reset' => 'La tua password è stata resettata!',
    'sent' => 'Abbiamo inviato per e-mail il tuo link per la reimpostazione della password!',
    'token' => 'Questo token di reimpostazione della password non è valido.',
    'user' => 'Non è possibile trovare un utente con quell\'indirizzo e-mail.',
];
